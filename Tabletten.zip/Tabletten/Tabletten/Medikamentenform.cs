﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tabletten
{
    abstract class Medikamentenform
    {
        private double gewichtlnG;
        private double laengelnMm;
        private double breitelnMm;
        private long id;

        public Medikamentenform( double gewichtlnG, double laengelnMm, double breitelnMm, long id )
        {
            this.gewichtlnG = gewichtlnG;
            this.laengelnMm = laengelnMm;
            this.breitelnMm = breitelnMm;
            this.id = id;
        }

        //abstract Methode hat keine Code drinen.
        public abstract String wirkstofffreisetzung();

        public void setGewichtlnG( double g ) { this.gewichtlnG = g;}
        public double getGewichtlnG(){ return gewichtlnG;}
        public void setLaengelnMm( double l ) {this.laengelnMm = l;}
        public double getLaengelnMm() { return laengelnMm; }
        public void setId( long id ) { this.id = id;}
        public long getId() { return id;}
        public void setBreitelnMm(double b) { this.breitelnMm = b; }
        public double getBreitelnMm() { return breitelnMm; }
    }
}
