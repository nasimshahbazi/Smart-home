﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tabletten
{
    class Tablettenform : Medikamentenform
    {
        private double pulverKoemunglnUm;

        public void setPulverKoemunglnUm( double p )
        {   this.pulverKoemunglnUm = p; }
        public double getPulverKoemunglnUm()
        {   return pulverKoemunglnUm; }

        public Tablettenform(double gewichtlnG, double laengelnMm, double breitelnMm, long id, double pulverKoemunglnUm): base(gewichtlnG, laengelnMm, breitelnMm, id)
        {
            this.pulverKoemunglnUm = pulverKoemunglnUm;

        }
 
        public override String wirkstofffreisetzung()
        {
            //return + Attributinhalt pulverKoemunglnUm;

            return  "Freisetzung des Wirkstoffes durch Zersetzung der Tablette Pulverkoernung in Mikromreter:" + pulverKoemunglnUm.ToString();
        }
        

    }
}
