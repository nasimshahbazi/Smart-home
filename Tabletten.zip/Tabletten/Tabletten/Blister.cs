﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tabletten
{
    class Blister
    {
        private int anzahlMulden;
        private int anzahlReihen;
        private int anzahlSpalten;
        private int anzahlMedikamente;

        private List<Medikament> medikamente;

        //zwei demonsiale Array [,]
        private Boolean[,] bestandInfo;
        private long id;

        public Blister( int anzahlReihen, int anzahlSpalten, long id, Medikament[] produzierteMedikament )
        {
            this.anzahlSpalten = anzahlSpalten;
            this.anzahlReihen = anzahlReihen;

            //Anzahl der Mulden ergibt sich aus der Multiplikation von anzahlReihen mit anzahlSpalten
            this.anzahlMulden = anzahlSpalten * anzahlReihen;

            medikamente = new List<Medikament>();
            bestandInfo = new Boolean[anzahlReihen, anzahlSpalten];


            //die übergebene Medicamente werden in die Liste der eigenen Medikamente aufgenommen.
            //Beschränkt wird die Aufnamne durch die Anzahl der Mulden im Blister
            if ( anzahlMulden < produzierteMedikament.Length )
                anzahlMedikamente = anzahlMulden;
            else
                anzahlMedikamente = produzierteMedikament.Length;

            //das Attribut anzahlMedikamente gibt die aktuelle Anzahl der Medikamente im Blister.
            for ( int i = 0; i < anzahlMedikamente; ++i )
            {
                medikamente.Add( produzierteMedikament[i] );
            }

            //das Attribut bestandInfio ;True: gibt ein Medikament in [,]  False: keine Medikament 
            int anz = 1;
            //erste schleife läuft in Reihen, Inen Schleife läuft in Spalten
            for (int r = 0; r < anzahlReihen; ++r)
                for (int s = 0; s < anzahlSpalten; ++s )
                {
                    if ( anz <= anzahlMedikamente )
                        bestandInfo[r, s] = true;
                    else
                        bestandInfo[r, s] = false;

                    ++anz;
                }
        }
        
        public void setAnzahlMulden(int am)
        {
            this.anzahlMulden = am;
        }
      
        public int getAnzahlMulden()
        {
            return anzahlMulden;
        }

        public void setAnzahlReihen( int ar )
        {
            this.anzahlReihen = ar;
        }

        public int getAnzahlReihen()
        {
            return anzahlReihen;
        }
        public void setAnzahlSpalten( int a )
        {
            this.anzahlSpalten = a;
        }

        public int getAnzahSpalten()
        {
            return anzahlSpalten;
        }

        public void setAnzahlMedikament( int am )
        {
            this.anzahlMedikamente = am;
        }

       
        public int getAnzahlMedikament()
        {
            return anzahlMulden;
        }

        public void setId(long d)
        {
            this.id = d;
        }


        public long getId()
        {
            return id;
        }


        public Boolean entnehmen(int indexReihe, int indexSpalte )
        {
            //Attributwerte der Klasse aktualisiert.
            if ( bestandInfo[indexReihe - 1, indexSpalte - 1] == true )
            {
                anzahlMedikamente--;
                bestandInfo[indexReihe - 1, indexSpalte - 1] = false;

                medikamente.RemoveAt(anzahlMedikamente);


                return true;
            }
            else
                return false;

            //Falls ein Medikament an der gewünschten Mulse nicht vorhanden ist, wird False zurückgeben, sonst true.


        }

        public void druckeBestandInfo()
        {
            //O, Mulde gefühllt, X, Mulde leer

            for ( int r = 0; r < anzahlReihen; ++r )
            {
                for ( int s = 0; s < anzahlSpalten; ++s )
                {
                    if ( bestandInfo[r, s] == true )
                        Console.Write( "O" );
                    else
                        Console.Write( "X" );

                }
                //neue Zeile.
                Console.WriteLine();
            }
        }
            
       

    }
}
