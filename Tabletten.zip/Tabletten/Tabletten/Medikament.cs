﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tabletten
{
    class Medikament
    {
        private String haltbarkeitsdatum;
        private String name;
        private String wirksamkeit;
        private long id;
        //Inhalt Beziehung
        private Medikamentenform arzneiForm;

        public Medikament(String haltbarkeitsdatum, String name, String wirksamkeit, Medikamentenform formInfos)
        {
            this.arzneiForm = formInfos;
            this.haltbarkeitsdatum = haltbarkeitsdatum;
            this.name = name;
            this.wirksamkeit = wirksamkeit;
            //Der Verweis formInfos ist eine Referenz auf ein Objekt das information für das eigene Attribut arzneiForm enthält.
            arzneiForm = formInfos;
        }

        public void setHaltbarkeitsdatum(String h)
        {
            this.haltbarkeitsdatum = h;
        }

        public String getHaltbarkeitsdatum()
        {
            return haltbarkeitsdatum;
        }

        public void setName(String n)
        {
            this.name = n;
        }

        public String getName()
        {
            return name;
        }

        public void setWirksamkeit(String w)
        {
            this.wirksamkeit = w;
        }

        public String getWirksamkeit()
        {
            return wirksamkeit;
        }

        public void setId(long i)
        {
            this.id = i;
        }

        public long getId()
        {
            return id;
        }
    }
}
