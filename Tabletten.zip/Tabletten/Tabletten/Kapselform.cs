﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tabletten
{
    class Kapselform : Medikamentenform
    {
        private double gelIMengelnG;


        public Kapselform( double gewichtlnG, double laengelnMm, double breitelnMm, long id, double gelMengelnG) : base( gewichtlnG, laengelnMm, breitelnMm, id )
        {
            this.gelIMengelnG = gelIMengelnG;


        }

        public void setGelIMengelnG( double g )
        {   this.gelIMengelnG = g; }
        public double getGelIMengelnG()
        {   return gelIMengelnG; }

        public override string wirkstofffreisetzung()
        {
            return "";
           
        }
        
    }
}
